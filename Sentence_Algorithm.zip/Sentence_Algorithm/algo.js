function LongWord() {

    var counter = 0;
    var sentence = "I love my life";
    for (var letter = 'a'; letter <= 'z'; letter++) {
        for (var i = 0; i < sentence.length(); i++) {
            if (sentence.charAt(i) == letter) {
                counter++;
            }
        }
        if (counter > 0) {
            console.log(letter + "=" + counter)
            counter = 0;
        }
    }
}

function vowel() {
    var vCount = 0,
        cCount = 0;


    var str = "This is a really simple sentence";

    str = str.toLowerCase();

    for (var i = 0; i < str.length(); i++) {

        if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u') {

            vCount++;
        } else if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') {

            cCount++;
        }
    }
}

function countWords() {

    var wc = 0;
    var i = 0;


    while (i < str.length()) {

        if (str.charAt(i) == ' ' || str.charAt(i) == '\n' ||
            str.charAt(i) == '\t')
            state = OUT;



        else if (state == OUT) {
            state = IN;
            ++wc;
        }


        ++i;
    }
    return wc;
}